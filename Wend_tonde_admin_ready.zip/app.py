﻿from flask import Flask, render_template, request, redirect, url_for
import csv
import os
from datetime import datetime

app = Flask(__name__)

TICKETS_FILE = 'tickets.csv'
TICKETS_TOTAL = 100

# Initialisation fichier CSV
if not os.path.exists(TICKETS_FILE):
    with open(TICKETS_FILE, 'w', newline='', encoding='utf-8') as f:
        writer = csv.writer(f)
        writer.writerow(['Nom ou Numéro', "Date d'achat"])

def nombre_tickets_vendus():
    with open(TICKETS_FILE, 'r', encoding='utf-8') as f:
        return sum(1 for row in csv.reader(f)) - 1  # en-tête exclu

@app.route('/')
def index():
    tickets_vendus = nombre_tickets_vendus()
    tickets_restants = TICKETS_TOTAL - tickets_vendus
    return render_template('index.html',
                           tickets_total=TICKETS_TOTAL,
                           tickets_vendus=tickets_vendus,
                           tickets_restants=tickets_restants)

@app.route('/acheter', methods=['POST'])
def acheter():
    nom = request.form['nom']
    date_achat = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    with open(TICKETS_FILE, 'a', newline='', encoding='utf-8') as f:
        writer = csv.writer(f)
        writer.writerow([nom, date_achat])
    return redirect(url_for('confirmation'))

@app.route('/confirmation')
def confirmation():
    return render_template('confirmation.html')

if __name__ == '__main__':
    app.run(debug=True) @app.route('/admin')
def admin():
    with open(TICKETS_FILE, 'r', encoding='utf-8') as f:
        reader = csv.reader(f)
        next(reader)  # Ignore l’en-tête
        participants = list(reader)
    
    tickets_vendus = len(participants)
    tickets_restants = TICKETS_TOTAL - tickets_vendus

    return render_template('admin.html',
                           participants=participants,
                           tickets_vendus=tickets_vendus,
                           tickets_restants=tickets_restants)
from flask import send_file

ADMIN_PASSWORD = 'motdepasse'  # change ce mot de passe à ta convenance

@app.route('/admin', methods=['GET', 'POST'])
def admin():
    if request.method == 'POST':
        password = request.form['password']
        if password == ADMIN_PASSWORD:
            return redirect(url_for('admin_dashboard'))
        else:
            return render_template('admin_login.html', erreur='Mot de passe incorrect')
    return render_template('admin_login.html')

@app.route('/admin/dashboard')
def admin_dashboard():
    with open(TICKETS_FILE, 'r', encoding='utf-8') as f:
        reader = csv.reader(f)
        participants = list(reader)[1:]  # on ignore l'en-tête
    return render_template('admin.html', participants=participants)

@app.route('/admin/telecharger')
def telecharger():
    return send_file(TICKETS_FILE, as_attachment=True)

@app.route('/admin/supprimer/<int:index>')
def supprimer(index):
    with open(TICKETS_FILE, 'r', encoding='utf-8') as f:
        lignes = list(csv.reader(f))
    if index + 1 < len(lignes):
        del lignes[index + 1]  # +1 car index 0 = en-tête
        with open(TICKETS_FILE, 'w', newline='', encoding='utf-8') as f:
            writer = csv.writer(f)
            writer.writerows(lignes)
    return redirect(url_for('admin_dashboard'))

@app.route('/admin/reset')
def reset():
    with open(TICKETS_FILE, 'w', newline='', encoding='utf-8') as f:
        writer = csv.writer(f)
        writer.writerow(['Nom ou Numéro', 'Date d\'achat'])
    return redirect(url_for('admin_dashboard'))